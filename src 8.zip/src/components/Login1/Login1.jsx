import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { writePasskey } from "../../services/loginService";
import {
  forceRefreshGatt,
  logServicesAndCharacteristics,
  manager,
} from "../../services/bleService";

const Login1 = ({ device, onLogin }) => {
  // ✅ user types passkey here
  const [passkey, setPasskey] = useState("");

  // ✅ UI states
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleLoginPress = async () => {
    if (!device) {
      setErrorMsg("No device connected.");
      return;
    }

    // ✅ basic validation
    if (!passkey || passkey.length < 4) {
      setErrorMsg("Please enter a valid passkey.");
      return;
    }

    try {
      setErrorMsg("");
      setIsLoading(true);

      console.log("[Login1] 🔐 Writing passkey...");
      const ok = await writePasskey(device, passkey);

      if (!ok) {
        setErrorMsg("Passkey write failed. Please try again.");
        return;
      }

      console.log("[Login1] ✅ Passkey written — refreshing GATT...");
      const refreshed = await forceRefreshGatt(device, manager);

      if (!refreshed) {
        setErrorMsg("GATT refresh failed. Please reconnect and try again.");
        return;
      }

      // Optional debug: log services map
      const uuidMap = await logServicesAndCharacteristics(refreshed);
      if (uuidMap) {
        console.log("[Login1] 📦 UUID MAP:");
        console.log(JSON.stringify(uuidMap, null, 2));
      }

      console.log("[Login1] ✅ Login complete");
      onLogin(); // ✅ go to Tabs
    } catch (err) {
      console.log("[Login1] ❌ Login flow failed:", err.message);
      setErrorMsg(err.message || "Login failed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Passkey</Text>

      <TextInput
        style={styles.input}
        value={passkey}
        onChangeText={setPasskey}
        placeholder="Passkey (e.g. 123456)"
        placeholderTextColor="#aaa"
        keyboardType="numeric"
        editable={!isLoading}
      />

      {errorMsg ? <Text style={styles.error}>{errorMsg}</Text> : null}

      <TouchableOpacity
        style={[styles.button, { opacity: isLoading ? 0.6 : 1 }]}
        onPress={handleLoginPress}
        disabled={isLoading}
      >
        {isLoading ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator color="#fff" />
            <Text style={styles.buttonText}>Logging in...</Text>
          </View>
        ) : (
          <Text style={styles.buttonText}>Login</Text>
        )}
      </TouchableOpacity>

      {!device && (
        <Text style={styles.hint}>⚠️ Connect Bluetooth device first.</Text>
      )}
    </View>
  );
};

export default Login1;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgb(31,31,31)",
    paddingHorizontal: 20,
  },
  title: {
    color: "white",
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#555",
    borderRadius: 10,
    padding: 14,
    color: "#fff",
    fontSize: 18,
    marginBottom: 10,
    backgroundColor: "#222",
  },
  button: {
    width: "100%",
    backgroundColor: "#0ee50be2",
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "#000",
    fontSize: 18,
    fontWeight: "bold",
  },
  loadingRow: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },
  error: {
    width: "100%",
    color: "#ff4d4d",
    marginTop: 6,
    marginBottom: 4,
    fontWeight: "bold",
  },
  hint: {
    marginTop: 20,
    color: "#aaa",
  },
});
