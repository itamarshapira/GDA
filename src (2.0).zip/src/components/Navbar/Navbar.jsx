// src/components/Navbar/Navbar.js

import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity } from "react-native";
import styles from "./NavbarStyles";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import {
  connectToDevice,
  disconnectDevice,
  logServicesAndCharacteristics,
  forceRefreshGatt,
  manager,
} from "../../services/bleService";
import { requestBlePermissions } from "../../services/androidService";
import { writePasskey } from "../../services/loginService";

const Navbar = (props) => { // props.onBleConnected, props.onBleDisconnected from App.js to inform connection state of BLE
  const [isBluetoothOn, setIsBluetoothOn] = useState(false); // Bluetooth icon state
  const [connectedDevice, setConnectedDevice] = useState(null); // Connected device state

  const handleBluetoothPress = async () => {
    console.log("🟦 Bluetooth icon clicked! (Navbar)");

    if (connectedDevice) {
      const success = await disconnectDevice(connectedDevice);
      if (success) {
        setConnectedDevice(null);
        setIsBluetoothOn(false);
        props.onBleDisconnected(); // tell App.js we're disconnected
      }
      return;
    }

    const granted = await requestBlePermissions();
    if (!granted) {
      console.log("❌ Permissions denied — cannot scan BLE");
      return;
    }

    console.log("✅ Permissions granted — starting BLE scan...");
    try {
      const device = await connectToDevice();
      if (!device) return;

      setConnectedDevice(device);
      setIsBluetoothOn(true);

      // ✅ Let App know we're connected and send the device
      props.onBleConnected(device);
      console.log("[Navbar] Notified App of BLE connection, sent device.");
      console.log("[Navbar] now login1 can use the device to write passkey.");

    } catch (error) {
      console.log("❌ Connection process failed:", error.message);
      setIsBluetoothOn(false);
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require("../../../assets/wideLogo.png")}
        style={styles.logo}
      />

      <TouchableOpacity onPress={handleBluetoothPress}>
        <MaterialCommunityIcons
          name={isBluetoothOn ? "bluetooth" : "bluetooth-off"}
          size={40}
          color={isBluetoothOn ? "#04de71ff" : "#ffffff"}
          style={styles.icon}
        />
      </TouchableOpacity>
    </View>
  );
};

export default Navbar;
