// src/components/Tabs/DeviceInfo/DeviceInfo.js
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { readDeviceInformation } from "../../../services/deviceInfoService";

const DeviceInfo = ({ device }) => {
  const [info, setInfo] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchInfo = async () => {
      if (!device) {
        setError("No BLE device");
        return;
      }

      console.log("[DeviceInfo] 📡 Reading...");
      const result = await readDeviceInformation(device);
      if (result) {
        console.log("[DeviceInfo] 👍 Success:", result);
        setInfo(result);
      } else {
        setError("Failed to read");
      }
    };

    fetchInfo();
  }, [device]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Device Information</Text>

      {error && <Text style={styles.error}>{error}</Text>}

      {info ? (
        <>
          <Text style={styles.text}>Manufacturer: {info.manufacturer}</Text>
          <Text style={styles.text}>Model: {info.modelNumber}</Text>
          <Text style={styles.text}>System ID: {info.systemID}</Text>
        </>
      ) : !error ? (
        <Text style={styles.text}>Reading...</Text>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgb(40,40,40)",
  },
  header: {
    color: "#fff",
    fontSize: 22,
    marginBottom: 20,
    fontWeight: "bold",
  },
  text: {
    color: "#ccc",
    fontSize: 16,
    marginBottom: 6,
  },
  error: {
    color: "tomato",
    marginBottom: 10,
  },
});

export default DeviceInfo;
