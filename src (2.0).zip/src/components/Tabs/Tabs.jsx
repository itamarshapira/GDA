// src/components/Tabs/Tabs.jsx
import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, } from "react-native";
import DeviceInfo from "./DeviceInfo/DeviceInfo";

const Tabs = ({ device }) => {
  const [selectedTab, setSelectedTab] = useState("deviceInfo");

  return (
    <View style={styles.container}>

      {/* TOP HALF — Future Video Stream */}
      <View style={styles.videoContainer}>
        <Text style={styles.videoText}>🎥 Video Placeholder</Text>
      </View>

      {/* BOTTOM HALF */}
      <View style={styles.bottomContainer}>

        {/* Menu Buttons */}
        <View style={styles.tabMenu}>
          <TouchableOpacity onPress={() => setSelectedTab("deviceInfo")}>
            <Text style={[
              styles.menuItem,
              selectedTab === "deviceInfo" && styles.active
            ]}>
              Device Info
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setSelectedTab("Alert")}>
            <Text style={[
              styles.menuItem,
              selectedTab === "Alert" && styles.active
            ]}>
              Alert Notifiction
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setSelectedTab("settings")}>
            <Text style={[
              styles.menuItem,
              selectedTab === "settings" && styles.active
            ]}>
              Settings
            </Text>
          </TouchableOpacity>
        </View>

        {/* Display Selected Content */}
        <View style={styles.screenArea}>
          {selectedTab === "deviceInfo" && <DeviceInfo device={device} />}
          {selectedTab === "Alert" && (
            <Text style={styles.fakeText}>Alerts Data Coming Soon</Text>
          )}
          {selectedTab === "settings" && (
            <Text style={styles.fakeText}>Settings Coming Soon</Text>
          )}
          
        </View>
      </View>
    </View>
  );
};

export default Tabs;


// ============ STYLES ============
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "black",
  },

  videoContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2d2d2d",
  },
  videoText: {
    fontSize: 20,
    color: "#aaa",
  },

  bottomContainer: {
    flex: 1,
    backgroundColor: "#222",
  },

  tabMenu: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    paddingVertical: 6,
    backgroundColor: "#333",
    borderBottomWidth: 1,
    borderBottomColor: "#444",
  },

  menuItem: {
    color: "#bbb",
    fontSize: 16,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },

  active: {
    color: "#b2b2f4ff",
    fontWeight: "bold",
    textDecorationLine: "underline",
  },

  screenArea: {
    flex: 1,
    padding: 12,
  },

  fakeText: {
    textAlign: "center",
    color: "white",
    marginTop: 25,
    fontSize: 18,
  },
});
