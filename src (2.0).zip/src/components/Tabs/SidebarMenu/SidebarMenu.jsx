// src/components/Tabs/SidebarMenu.js
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

const SidebarMenu = ({ currentTab, setCurrentTab }) => {
  const menuItems = [
    { key: "DeviceInfo", label: "Device Info" },
    // Later we add more: GasData, Settings…
  ];

  return (
    <View style={styles.menu}>
      {menuItems.map((item) => {
        const isSelected = item.key === currentTab;
        return (
          <TouchableOpacity
            key={item.key}
            style={[styles.menuItem, isSelected && styles.menuItemActive]}
            onPress={() => setCurrentTab(item.key)}
          >
            <Text
              style={[styles.menuText, isSelected && styles.menuTextActive]}
            >
              {item.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  menu: {
  width: 160, // make it wider and very visible
  backgroundColor: "#1e1e1e",
  paddingTop: 30,
  borderRightWidth: 2,       // ← NEW DEBUG HELPER
  borderRightColor: "#4b46ac", // ← NEW DEBUG HELPER
},

  menuItem: {
    paddingVertical: 14,
    paddingHorizontal: 10,
  },
  menuItemActive: {
    backgroundColor: "#4b46ac",
    borderRadius: 6,
  },
  menuText: {
    color: "#bbbbbb",
    fontSize: 14,
  },
  menuTextActive: {
    color: "#ffffff",
    fontWeight: "bold",
  },
});

export default SidebarMenu;
