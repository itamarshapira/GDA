import { useEffect, useRef } from "react";
import { AppState, Platform } from "react-native";
import NetInfo from "@react-native-community/netinfo";
import {
  compareDeviceSsid,
  normalizeSsid,
  readPhoneWifiSsid,
} from "../services/wifiSsidService";

const CHECK_INTERVAL_MS = 5000;

/**
 * First-stage, log-only SSID diagnostics for the two existing Info tabs.
 * deviceSsid comes from their existing BLE result, never from a new BLE query.
 * No Camera Header UI or video/Zoom behavior is involved.
 */
export default function useWifiSsidDiagnostics(deviceId, deviceSsid) {
  const permissionAttemptedRef = useRef(false);

  useEffect(() => {
    if (Platform.OS !== "android" || !deviceId) return;

    let disposed = false;
    let inFlight = false;
    let queued = false;
    let foreground = AppState.currentState === "active";
    let generation = 0;
    let lastReport = null;

    const check = async (trigger) => {
      if (disposed || !foreground) return;
      if (inFlight) {
        queued = true; // Coalesce simultaneous resume/network/poll events.
        return;
      }
      inFlight = true;
      const startedGeneration = generation;
      const requestPermission = !permissionAttemptedRef.current;
      permissionAttemptedRef.current = true;

      try {
        const phone = await readPhoneWifiSsid({ requestPermission });
        // A native request cannot be cancelled. Ignore its result if this tab,
        // BLE device/SSID, or foreground session changed while awaiting it.
        if (disposed || !foreground || generation !== startedGeneration) return;
        const report = {
          deviceId,
          deviceSsid: normalizeSsid(deviceSsid),
          ...phone,
          ssidComparison: compareDeviceSsid(phone.phoneSsid, deviceSsid),
        };
        const signature = JSON.stringify(report);
        if (signature !== lastReport || trigger === "foreground") {
          lastReport = signature;
          // Intentional local diagnostics for this first step. Network names
          // may be private: redact them before sharing logs outside testing.
          console.log("[WiFiSSID]", JSON.stringify({
            ...report,
            trigger,
            checkedAt: new Date().toISOString(),
          }));
        }
      } finally {
        inFlight = false;
        if (queued && !disposed && foreground) {
          queued = false;
          void check("queued");
        }
      }
    };

    // Read on mount and when the BLE-reported SSID arrives/changes. An existing
    // permission grant (often obtained by BLE) is reused. Only the first check
    // per Info-tab mount may ask; later checks never repeat a denied prompt.
    void check("mount-or-device-ssid");
    const unsubscribe = NetInfo.addEventListener(() => {
      // Retire an in-flight snapshot taken before this network-change event.
      generation += 1;
      void check("network-change");
    });
    const appSubscription = AppState.addEventListener("change", (state) => {
      foreground = state === "active";
      generation += 1;
      if (foreground) void check("foreground");
    });

    // NetInfo's events follow the DEFAULT network. A local AP/SSID can change
    // without a cellular default-route change, so also check every five seconds.
    // This timer reads only while this Info tab is mounted and foregrounded.
    const timer = setInterval(() => { void check("poll"); }, CHECK_INTERVAL_MS);

    return () => {
      disposed = true;
      generation += 1;
      clearInterval(timer);
      unsubscribe();
      appSubscription.remove();
    };
  }, [deviceId, deviceSsid]);
}
