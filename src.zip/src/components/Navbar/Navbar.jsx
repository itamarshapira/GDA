// src/components/Navbar/Navbar.js

import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity } from "react-native";
import styles from "./NavbarStyles";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import {
  connectToDevice,
  disconnectDevice,
  logServicesAndCharacteristics,
  forceRefreshGatt,
  manager,
} from "../../services/bleService";
import { requestBlePermissions } from "../../services/androidService";
import { writePasskey } from "../../services/loginService";

const Navbar = () => {
  const [isBluetoothOn, setIsBluetoothOn] = useState(false);
  const [connectedDevice, setConnectedDevice] = useState(null);

  const handleBluetoothPress = async () => {
    console.log("🟦 Bluetooth icon clicked! (Navbar)");

    if (connectedDevice) {
      const success = await disconnectDevice(connectedDevice);
      if (success) {
        setConnectedDevice(null);
        setIsBluetoothOn(false);
      }
      return;
    }

    const granted = await requestBlePermissions();
    if (!granted) {
      console.log("❌ Permissions denied — cannot scan BLE");
      return;
    }

    console.log("✅ Permissions granted — starting BLE scan...");
    try {
      const device = await connectToDevice();
      if (!device) return;

      setConnectedDevice(device);
      setIsBluetoothOn(true);

      console.log("🔐 Writing passkey...");
      const ok = await writePasskey(device, "123456");

      if (ok) {
        console.log("✅ Passkey written successfully — refreshing GATT...");
        const refreshed = await forceRefreshGatt(device, manager);
        if (refreshed) {
          await logServicesAndCharacteristics(refreshed);
        } else {
          console.log("⚠️ GATT refresh failed — reconnect manually.");
        }
      } else {
        console.log("❌ Passkey write failed");
      }
    } catch (error) {
      console.log("❌ Connection process failed:", error.message);
      setIsBluetoothOn(false);
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require("../../../assets/wideLogo.png")}
        style={styles.logo}
      />

      <TouchableOpacity onPress={handleBluetoothPress}>
        <MaterialCommunityIcons
          name={isBluetoothOn ? "bluetooth" : "bluetooth-off"}
          size={40}
          color={isBluetoothOn ? "#04de71ff" : "#ffffff"}
          style={styles.icon}
        />
      </TouchableOpacity>
    </View>
  );
};

export default Navbar;
