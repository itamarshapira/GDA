// src/services/mediaControlService.js

/**
 * Media Control Service
 * ---------------------
 * Service UUID: 0x1848
 * Characteristic: Media Control Point (0x2BA4)
 *
 * Values (enum, UInt8):
 * 0 = Normal
 * 1 = Alignment
 * 2 = Zero Calibration
 */

import {
  MEDIA_CONTROL_UUID,
  MEDIA_CONTROL_POINT_UUID,
  AXIS_COORDINATE_UUID,
  RESOLUTION_CONTROL_UUID,
} from "./bleUuidLabels";

import {
  readUint8Characteristic,
  writeUint8Characteristic,
} from "./bleService";

/**
 * Read current Media Control state
 * @returns {number|null} 0 | 1 | 2
 */
export async function readMediaControlState(device) {
  if (!device) {
    console.log("[MediaControl] ❌ No device");
    return null;
  }

  try {
    console.log("[MediaControl] 📖 Reading state...");

    const value = await readUint8Characteristic(
      device,
      MEDIA_CONTROL_UUID,
      MEDIA_CONTROL_POINT_UUID
    );

    if (value === null) {
      console.log("[MediaControl] ⚠️ State is null");
      return null;
    }

    console.log("[MediaControl] ✅ State =", value);
    return value;
  } catch (err) {
    console.log("[MediaControl] ❌ Failed to read state:", err.message);
    return null;
  }
}

/**
 * Write Media Control command
 * @param {number} value 0 | 1 | 2
 */
export async function writeMediaControlState(device, value) {
  if (!device) {
    console.log("[MediaControl] ❌ No device");
    return false;
  }

  try {
    console.log("[MediaControl] ✍️ Writing state:", value);

    const ok = await writeUint8Characteristic(
      device,
      MEDIA_CONTROL_UUID,
      MEDIA_CONTROL_POINT_UUID,
      value
    );

    return ok;
  } catch (err) {
    console.log("[MediaControl] ❌ Failed to write state:", err.message);
    return false;
  }
}

/**
 * Read Axis Coordinates (X/Y/Z) raw
 * We first log bytes to understand firmware format.
 */
export async function readAxisRaw(device) {
  if (!device) {
    console.log("[Axis] ❌ No device");
    return null;
  }

  try {
    console.log("[Axis] 📖 Reading raw axis data...");

    const char = await device.readCharacteristicForService(
      MEDIA_CONTROL_UUID,
      AXIS_COORDINATE_UUID
    );

    if (!char?.value) return null;

   const bytes = Buffer.from(char.value, "base64");

console.log("[AxisService] Raw bytes:", bytes);
console.log("[AxisService] Hex:", bytes.toString("hex"));

// Decode as Int16 Little Endian
if (bytes.length >= 6) {
  const x = bytes.readInt16LE(0);
  const y = bytes.readInt16LE(2);
  const z = bytes.readInt16LE(4);

  console.log("[AxisService] Decoded:", { x, y, z });

  // --- Add G-force conversion ---
  // Common IMU scale (we verify if correct)
  const SCALE = 2048;

  const gx = x / SCALE;
const gy = y / SCALE;
const gz = z / SCALE;

// Magnitude is the total acceleration vector length.
// Why:
// - When the detector is standing still, the magnitude should be close to 1g.
// - This helps us verify if SCALE = 20000 is actually correct.
// Example:
// - gx=0, gy=0, gz=1 → magnitude = 1g
// - gx=0.5, gy=0, gz=0.5 → magnitude ≈ 0.707g
const magnitude = Math.sqrt(gx * gx + gy * gy + gz * gz);

console.log("[AxisService] Raw:", { x, y, z });
console.log("[AxisService] G-force:", { gx, gy, gz, magnitude });

// Simple orientation hint based on the strongest gravity axis.
// Why:
// - Raw gx/gy/gz numbers are useful for debugging,
//   but not very clear for an operator.
// - This tells us which axis is currently closest to gravity.
// Example:
// - gy ≈ -1 means the detector's Y axis is mostly aligned with gravity.
const absX = Math.abs(gx);
const absY = Math.abs(gy);
const absZ = Math.abs(gz);

let orientationHint = "Unknown orientation";

if (absX >= absY && absX >= absZ) {
  orientationHint = gx >= 0 ? "+X axis down" : "-X axis down";
} else if (absY >= absX && absY >= absZ) {
  orientationHint = gy >= 0 ? "+Y axis down" : "-Y axis down";
} else {
  orientationHint = gz >= 0 ? "+Z axis down" : "-Z axis down";
}

return { x, y, z, gx, gy, gz, magnitude, orientationHint };
}
  } catch (err) {
    console.log("[AxisService] ❌ Read failed:", err.message);
    return null;
  }
}

/**
 * Monitor Axis G-force (X/Y/Z) using NOTIFY
 * Returns subscription (must remove() to stop)
 */
export const monitorAxis = (device, onValue) => {
  if (!device) {
    console.log("[AxisService] ❌ No device for monitor");
    return null;
  }

  console.log("[AxisService] 📡 Subscribing to Axis notify...");

  const subscription = device.monitorCharacteristicForService(
    MEDIA_CONTROL_UUID,
    AXIS_COORDINATE_UUID,
    (error, characteristic) => {
      if (error) {
        console.log("[AxisService] ❌ Notify error:", error.message);
        return;
      }

      if (!characteristic?.value) return;

      try {
        const bytes = Buffer.from(characteristic.value, "base64");

        if (bytes.length < 6) return;

        const x = bytes.readInt16LE(0);
        const y = bytes.readInt16LE(2);
        const z = bytes.readInt16LE(4);

        const SCALE = 2048;

        const gx = x / SCALE;
        const gy = y / SCALE;
        const gz = z / SCALE;

        console.log("[AxisService] 🔔 Notify:", { gx, gy, gz });

        if (typeof onValue === "function") {
          onValue({ x, y, z, gx, gy, gz });
        }
      } catch (e) {
        console.log("[AxisService] Decode failed:", e.message);
      }
    }
  );

  return subscription;
};

/**
 * Write video resolution command to the MCU.
 *
 * Values:
 * 0 = Zoom In  -> RPI maps to FoV 4 (center crop)
 * 1 = Zoom Out -> RPI maps to FoV 100 (full image)
 * This selects FoV, not a 640x480 output size. The camera normally outputs
 * 1280x960. A BLE response does not confirm the Pi helper/reload has completed.
 */
export async function writeResolutionControl(device, value) {
  if (!device) {
    console.log("mediaControlService.js: Zoom write rejected - no device");
    return false;
  }

  if (value !== 0 && value !== 1) {
    console.log("mediaControlService.js: Zoom write rejected - invalid value:", value);
    return false;
  }

  const startedAt = Date.now();
  const command = {
    deviceId: device.id,
    value,
    expectedFov: value === 0 ? 4 : 100,
    serviceUUID: MEDIA_CONTROL_UUID,
    characteristicUUID: RESOLUTION_CONTROL_UUID,
    timestamp: new Date(startedAt).toISOString(),
  };
  try {
    console.log("mediaControlService.js: Zoom BLE write started:", command);

    // Preserve the firmware contract: one UInt8 byte, with response, awaited.
    // No readback/notify completion protocol is defined here; do not infer Pi
    // success from this BLE result or automatically resend a failed command.
    const ok = await writeUint8Characteristic(
      device,
      MEDIA_CONTROL_UUID,
      RESOLUTION_CONTROL_UUID,
      value
    );

    console.log(
      ok
        ? "mediaControlService.js: Zoom BLE write succeeded; Raspberry Pi FoV unverified:"
        : "mediaControlService.js: Zoom BLE write failed; no automatic retry:",
      { ...command, elapsedMs: Date.now() - startedAt },
    );
    return ok;
  } catch (err) {
    console.log("mediaControlService.js: Zoom BLE write threw:", command, err.message);
    return false;
  }
}
