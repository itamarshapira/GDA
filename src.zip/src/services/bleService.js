// src/services/bleService.js

import { BleManager } from "react-native-ble-plx";

// Create a shared BLE manager for the whole app
export const manager = new BleManager();

/**
 * Connects to the first FG device found.
 */
export async function connectToDevice() {
  console.log("🔍 Scanning for BLE devices... (bleService.js)");
  let isConnected = false;

  return new Promise((resolve, reject) => {
    manager.startDeviceScan(null, null, async (error, device) => {
      if (error) {
        console.log("❌ Scan error:", error);
        manager.stopDeviceScan();
        reject(error);
        return;
      }

      if (device && device.name && /^fg/i.test(device.name)) {
        console.log(`✅ Found FG device: ${device.name}`);
        manager.stopDeviceScan();

        try {
          console.log("🔗 Connecting...");
          const connectedDevice = await device.connect();
          console.log(`✅ Connected to: ${connectedDevice.name}`);
          isConnected = true;

          await connectedDevice.discoverAllServicesAndCharacteristics();
          console.log("🔎 Services & characteristics discovered");

          await logServicesAndCharacteristics(connectedDevice);
          resolve(connectedDevice);
        } catch (err) {
          console.log("❌ Connection error:", err);
          reject(err);
        }
      }
    });

    setTimeout(() => {
      if (!isConnected) {
        console.log("⏱️ Scan timeout — device not found.");
        manager.stopDeviceScan();
        reject(new Error("Device not found"));
      }
    }, 30000);
  });
}

/**
 * Disconnects from the connected BLE device.
 */
export async function disconnectDevice(device) {
  try {
    if (device) {
      console.log(`🔌 Disconnecting from ${device.name || "device"}...`);
      await device.cancelConnection();
      console.log("✅ Disconnected successfully.");
      return true;
    }
    console.log("⚠️ No device to disconnect.");
    return false;
  } catch (error) {
    console.log("❌ Disconnect error:", error);
    return false;
  }
}

/**
 * Lists all services and characteristics of a connected device.
 */
export async function logServicesAndCharacteristics(device) {
  try {
    const services = await device.services();

    for (const service of services) {
      console.log(`Service: ${service.uuid}`);
      const characteristics = await service.characteristics();

      for (const char of characteristics) {
        console.log(`   Characteristic: ${char.uuid}`);
        console.log(
          `      Properties:`,
          char.isReadable ? "READ " : "",
          char.isWritableWithResponse ? "WRITE " : "",
          char.isWritableWithoutResponse ? "WRITE_NO_RESP " : "",
          char.isNotifiable ? "NOTIFY " : "",
          char.isIndicatable ? "INDICATE" : ""
        );
      }
    }
    console.log("✅ Finished listing services and characteristics.");
  } catch (error) {
    console.log("❌ Error listing services:", error);
  }
}

/**
 * Forces Android to refresh the GATT table.
 * (Android caches the GATT after first connect.)
 */
export async function forceRefreshGatt(device) {
  try {
    if (!device) {
      console.log("[BleRefresh] ❌ No device provided");
      return null;
    }

    console.log("[BleRefresh] 🔄 Forcing GATT refresh...");
    await device.cancelConnection();
    await new Promise((r) => setTimeout(r, 1000));

    const newDevice = await manager.connectToDevice(device.id, {
      autoConnect: false,
    });
    await newDevice.discoverAllServicesAndCharacteristics();

    console.log("[BleRefresh] ✅ GATT rediscovery complete");
    return newDevice;
  } catch (e) {
    console.log("[BleRefresh] ❌ Failed to refresh GATT:", e.message);
    return null;
  }
}
